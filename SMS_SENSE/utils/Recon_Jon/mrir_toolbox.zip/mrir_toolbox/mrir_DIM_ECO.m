function dim = mrir_DIM_ECO(varargin)


dim = 05;



return;
