function dim = mrir_DIM_PHS(varargin)


dim = 06;



return;
