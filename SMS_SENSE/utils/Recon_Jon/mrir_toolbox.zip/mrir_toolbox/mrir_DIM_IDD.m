function dim = mrir_DIM_IDD(varargin)


dim = 14;



return;
