function dim = mrir_DIM_IDE(varargin)


dim = 15;



return;
