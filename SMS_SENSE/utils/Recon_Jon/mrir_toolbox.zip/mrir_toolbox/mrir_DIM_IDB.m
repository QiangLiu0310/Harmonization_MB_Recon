function dim = mrir_DIM_IDB(varargin)


dim = 12;



return;
