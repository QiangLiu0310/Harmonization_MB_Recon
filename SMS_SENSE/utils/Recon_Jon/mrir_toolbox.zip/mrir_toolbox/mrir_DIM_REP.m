function dim = mrir_DIM_REP(varargin)


dim = 07;



return;
