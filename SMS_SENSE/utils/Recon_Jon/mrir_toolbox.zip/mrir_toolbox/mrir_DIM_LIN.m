function dim = mrir_DIM_LIN(varargin)


dim = 02;



return;
