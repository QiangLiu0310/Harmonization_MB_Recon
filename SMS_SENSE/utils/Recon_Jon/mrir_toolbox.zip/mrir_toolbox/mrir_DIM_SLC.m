function dim = mrir_DIM_SLC(varargin)


dim = 10;



return;
