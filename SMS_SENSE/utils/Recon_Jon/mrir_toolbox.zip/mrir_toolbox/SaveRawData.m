function SaveRawData(meas,filename)

if (~isempty(meas.data))
    fname1 =  [filename(1:end-4) '_RawData.data'];
    SaveToDat(meas.data, fname1);
end
if (~isempty(meas.data_phascor1d))
    fname2 =  [filename(1:end-4) '_RawData_nav.data'];
    SaveToDat(meas.data_phascor1d, fname2);
end
meas.data = [];
meas.data_phascor1d = [];

if isfield(meas, 'patrefscan')
    if (~isempty(meas.patrefscan))
        fname3 =  [filename(1:end-4) '_RawACS.data'];
        SaveToDat(meas.patrefscan, fname3);
    end
    if (~isempty(meas.patrefscan_phascor))
        fname4 =  [filename(1:end-4) '_RawACS_nav.data'];
        SaveToDat(meas.patrefscan_phascor, fname4);
    end
    meas.patrefscan = [];
    meas.patrefscan_phascor = [];
end

eval(['save ' filename(1:end-4) '_Raw.mat meas'])