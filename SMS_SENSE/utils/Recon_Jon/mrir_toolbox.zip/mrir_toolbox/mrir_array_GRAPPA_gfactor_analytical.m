function mrir_array_GRAPPA_gfactor_analytical(k_kernel, Ncol, Nlin)
  
  
  i_kernel = ifft2(k_kernel);

