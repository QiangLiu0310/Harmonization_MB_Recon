function img_shifted = mrir_phase_array_combine_preshift(img, varargin)
%MRIR_PHASE_ARRAY_COMBINE_PRESHIFT
%
% img_shifted = mrir_phase_array_combine_preshift(img)

% jonathan polimeni <jonp@nmr.mgh.harvard.edu>, 2009/feb/12
% $Id$
%**************************************************************************%

  VERSION = '$Revision: 1.5 $';
  if ( nargin == 0 ), help(mfilename); return; end;


  %==--------------------------------------------------------------------==%


  
    return;


  %************************************************************************%
  %%% $Source: /home/jonnyreb/cvsroot/dotfiles/emacs,v $
  %%% Local Variables:
  %%% mode: Matlab
  %%% fill-column: 76
  %%% comment-column: 0
  %%% End:
