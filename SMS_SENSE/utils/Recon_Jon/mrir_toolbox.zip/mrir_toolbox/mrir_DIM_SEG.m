function dim = mrir_DIM_SEG(varargin)


dim = 08;



return;
