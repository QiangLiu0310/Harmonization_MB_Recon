function dim = mrir_DIM_IDA(varargin)


dim = 11;



return;
