

ordfilt2
medfilt2

imfilter