

% used by breuer2006development_THESIS for sensitivity map computation