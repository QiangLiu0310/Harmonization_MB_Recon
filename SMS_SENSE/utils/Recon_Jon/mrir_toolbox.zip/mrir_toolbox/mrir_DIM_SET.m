function dim = mrir_DIM_SET(varargin)


dim = 04;



return;
