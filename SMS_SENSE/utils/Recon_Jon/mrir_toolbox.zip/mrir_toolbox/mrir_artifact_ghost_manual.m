function linear_coeff = mrir_artifact_ghost_manual(coeff0, coeff1)
%MRIR_ARTIFACT_GHOST_MANUAL
%
% linear_coeff = mrir_artifact_ghost_manual(coeff0, coeff1)

% jonathan polimeni <jonp@padkeemao.nmr.mgh.harvard.edu>, 2007/jan/24
% $Id: mrir_artifact_ghost_manual.m,v 1.1 2007/11/14 03:05:16 jonp Exp $
%**************************************************************************%

  VERSION = '$Revision: 1.1 $';
  if ( nargin == 0 ), help(mfilename); return; end;


  %==--------------------------------------------------------------------==%

  %%% NOT YET IMPLEMENTED


  return;


  %************************************************************************%
  %%% $Source: /space/padkeemao/1/users/jonp/cvsjrp/PROJECTS/IMAGE_RECON/mrir_toolbox/mrir_artifact_ghost_manual.m,v $
  %%% Local Variables:
  %%% mode: Matlab
  %%% fill-column: 76
  %%% comment-column: 0
  %%% End:
