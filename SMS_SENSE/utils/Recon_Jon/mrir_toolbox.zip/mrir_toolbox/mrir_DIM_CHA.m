function dim = mrir_DIM_CHA(varargin)


dim = 03;



return;
