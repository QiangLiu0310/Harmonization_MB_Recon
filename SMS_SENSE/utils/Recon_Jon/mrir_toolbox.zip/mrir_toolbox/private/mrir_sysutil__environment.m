

global DEBUG; if ( isempty(DEBUG) ), DEBUG = 0; end;

  
  
  
global PRELUDE;
PRELUDE = '/usr/pubsw/packages/fsl/current/bin/prelude';