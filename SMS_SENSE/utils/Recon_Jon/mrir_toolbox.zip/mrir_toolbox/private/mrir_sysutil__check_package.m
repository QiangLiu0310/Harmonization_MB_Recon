function msg = mrir_util__check_package(package_str)
%

% jonathan polimeni <jonp@nmr.mgh.harvard.edu>, 2008/jun/30
% $Id$
%**************************************************************************%

  VERSION = '$Revision: 1.5 $';
  if ( nargin == 0 ), help(mfilename); return; end;


  %==--------------------------------------------------------------------==%

  
  
  
  
  nifti_download = 'http://www.mathworks.com/matlabcentral/fileexchange/loadFile.do?objectId=8797&objectType=file';
  

  fsl_download = 'http://www.fmrib.ox.ac.uk/fsl/';

  
  msg = '';
  
  
  
  return;


  %************************************************************************%
  %%% $Source: /home/jonnyreb/cvsroot/dotfiles/emacs,v $
  %%% Local Variables:
  %%% mode: Matlab
  %%% fill-column: 76
  %%% comment-column: 0
  %%% End:

  