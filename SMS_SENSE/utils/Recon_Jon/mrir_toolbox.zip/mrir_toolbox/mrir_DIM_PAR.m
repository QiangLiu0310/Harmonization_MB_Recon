function dim = mrir_DIM_PAR(varargin)


dim = 09;



return;
