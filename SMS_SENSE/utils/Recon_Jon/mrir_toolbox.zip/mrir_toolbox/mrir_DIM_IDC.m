function dim = mrir_DIM_IDC(varargin)


dim = 13;



return;
