function dim = mrir_DIM_AVE(varargin)


dim = 16;



return;
