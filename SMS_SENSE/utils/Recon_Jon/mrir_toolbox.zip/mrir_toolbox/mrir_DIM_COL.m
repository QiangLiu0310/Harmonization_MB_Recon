function dim = mrir_DIM_COL(varargin)


dim = 01;



return;
